create
    definer = root@localhost procedure L2(IN num int)
begin
    declare sum int default 0;
    repeat
        set sum := sum +num;
        set num := num -1;
    until num <=0
    end repeat;
select sum;
end;

