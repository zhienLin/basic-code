create
    definer = root@localhost procedure L6(IN num int)
begin
    declare sum int default 0;
    Sum :
    loop
        if num <= 0 then
            leave Sum;
        end if;
        if num % 2 = 1 then
            set num := num - 1;
            iterate Sum;
        end if;
        set sum := sum + num;
        set num := num - 1;
    end loop Sum;
    select sum;
end;

