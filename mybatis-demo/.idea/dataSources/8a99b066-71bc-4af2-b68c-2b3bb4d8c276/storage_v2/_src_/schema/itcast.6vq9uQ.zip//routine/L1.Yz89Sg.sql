create
    definer = root@localhost procedure L1(IN num int)
begin
declare sum int default 0;
while num >0 do
    set sum := sum + num;
    set num := num -1;
    end while;
select sum;
end;

